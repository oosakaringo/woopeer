let e_modalCanvas;
let e_context;
let e_img;
let isDragging = false;
let startX;
let startY;
let lastX = 0;
let lastY = 0;
let newX = 0;
let newY = 0;
let newWidth;
let newHeight;
let scale = 1;
let ratio = 1;
let v_width;
let v_height;

let e_sendUserImg = document.getElementById('send_userimg');
let e_canvas=document.querySelector('.js-canvas');
f_canvasSet(e_canvas);
function f_canvasSet(el) {  
  e_modalCanvas = el;
  e_context = e_modalCanvas.getContext('2d');
  e_img = new Image();
  e_img.onload = () => {
    calculateImageDimensions();
    drawImageOnCanvas();
    e_modalCanvas.addEventListener('touchstart', handleDragStart);
    e_modalCanvas.addEventListener('touchmove', handleTouchMove);
    e_modalCanvas.addEventListener('wheel', handleWheel);
    e_modalCanvas.addEventListener('mousedown', handleDragStart);
    ['mouseup', 'mouseout', 'touchend'].forEach(eventName => e_modalCanvas.addEventListener(eventName, handleDragEnd));
    e_modalCanvas.addEventListener('mousemove', handleMouseMove);
  };
  e_img.src = 'files/img/icon_camera.png';
}
function calculateImageDimensions() {
  const { width, height } = e_img;
  const widthRatio = e_modalCanvas.width / width;
  const heightRatio = e_modalCanvas.height / height;
  ratio = Math.max(widthRatio, heightRatio);
  v_width = width * ratio;
  v_height = height * ratio;
  newX = Math.min((e_modalCanvas.width - v_width) / 2, 0);
  newY = Math.min((e_modalCanvas.height - v_height) / 2, 0);
  newWidth = v_width;
  newHeight = v_height;
}

function drawImageOnCanvas() {
  const { width, height } = e_modalCanvas;
  e_context.clearRect(0, 0, width, height);
  e_context.drawImage(e_img, newX, newY, newWidth, newHeight);
}
function handleDragStart(event) {
  event.preventDefault();
  isDragging = true;
  if (event.touches && event.touches.length > 0) {
    startX = event.touches[0].clientX;
    startY = event.touches[0].clientY;
  } else {
    startX = event.clientX;
    startY = event.clientY;
  }
  lastX = newX;
  lastY = newY;
  if (event.touches && event.touches.length > 1) {
    const [touch1, touch2] = event.touches;
    startX = (touch1.clientX + touch2.clientX) / 2;
    startY = (touch1.clientY + touch2.clientY) / 2;
    v_beforX = startX;
    v_beforY = startY;
    initialDistance = Math.hypot(touch2.clientX - touch1.clientX, touch2.clientY - touch1.clientY);
    initialScale = scale;
  }
}

function handleDragEnd() {
  isDragging = false;
  initialDistance = 0;
  initialScale = scale;
}

function handleTouchMove(event) {
  event.preventDefault();
  if (event.touches.length === 1 && isDragging) {
    const touch = event.touches[0];
    const clientX = touch.clientX;
    const clientY = touch.clientY;
    const deltaX = clientX - startX;
    const deltaY = clientY - startY;
    newX = lastX + deltaX * scale * ratio;
    newY = lastY + deltaY * scale * ratio;
    const minX = e_modalCanvas.width - newWidth;
    const minY = e_modalCanvas.height - newHeight;
    newX = Math.max(Math.min(newX, 0), minX);
    newY = Math.max(Math.min(newY, 0), minY);
    drawImageOnCanvas();
  } else if (event.touches.length > 1) {
    const [touch1, touch2] = event.touches;
    const currentDistance = Math.hypot(touch2.clientX - touch1.clientX, touch2.clientY - touch1.clientY);
    const delta = currentDistance - initialDistance;
    const zoom = 1 + delta * 0.01;
    scale = Math.max(initialScale * zoom, 1);
    const rect = e_modalCanvas.getBoundingClientRect();
    const offsetX = (touch1.clientX + touch2.clientX) / 2;
    const offsetY = (touch1.clientY + touch2.clientY) / 2;
    const preRatioX = (offsetX - newX) / newWidth;
    const preRatioY = (offsetY - newY) / newHeight;
    newWidth = v_width * scale;
    newHeight = v_height * scale;
    newX = offsetX - preRatioX * newWidth + (offsetX - startX) * scale;
    newY = offsetY - preRatioY * newHeight + (offsetY - startY) * scale;
    const minX = e_modalCanvas.width - newWidth;
    const minY = e_modalCanvas.height - newHeight;
    drawImageOnCanvas();
    lastX = newX;
    lastY = newY;
    startX = offsetX;
    startY = offsetY;
  }
}

function handleWheel(event) {
  event.preventDefault();
  const delta = Math.sign(event.deltaY);
  const zoom = delta > 0 ? 0.9 : 1.1;
  scale *= zoom;
  scale = Math.min(Math.max(scale, 1), 4);
  const offsetX = event.clientX - e_modalCanvas.getBoundingClientRect().left;
  const offsetY = event.clientY - e_modalCanvas.getBoundingClientRect().top;
  const preRatioX = (offsetX - newX) / newWidth;
  const preRatioY = (offsetY - newY) / newHeight;
  newWidth = v_width * scale;
  newHeight = v_height * scale;
  newX = offsetX - preRatioX * newWidth;
  newY = offsetY - preRatioY * newHeight;
  const minX = e_modalCanvas.width - newWidth;
  const minY = e_modalCanvas.height - newHeight;
  newX = Math.max(Math.min(newX, 0), minX);
  newY = Math.max(Math.min(newY, 0), minY);
  drawImageOnCanvas();
}

function handleMouseMove(event) {
  if (!isDragging) return;
  newX = lastX + (event.clientX - startX) * scale * ratio;
  newY = lastY + (event.clientY - startY) * scale * ratio;
  const minX = e_modalCanvas.width - newWidth;
  const minY = e_modalCanvas.height - newHeight;
  newX = Math.max(Math.min(newX, 0), minX);
  newY = Math.max(Math.min(newY, 0), minY);
  drawImageOnCanvas();
}

function drawImageOnCanvas() {
  e_context.clearRect(0, 0, e_modalCanvas.width, e_modalCanvas.height);
  e_context.drawImage(e_img, newX, newY, newWidth, newHeight);
}
function f_imgChange(e_file) {
  e_modalCanvas = e_file.nextElementSibling;
  e_context = e_modalCanvas.getContext('2d');
  e_img = new Image();
  scale = 1;
  e_img.onload = () => {
    const widthRatio = e_modalCanvas.width / e_img.width;
    const heightRatio = e_modalCanvas.height / e_img.height;
    ratio = Math.max(widthRatio, heightRatio);
    v_width = e_img.width * ratio;
    v_height = e_img.height * ratio;
    newX = Math.min((e_modalCanvas.width - v_width) / 2, 0);
    newY = Math.min((e_modalCanvas.height - v_height) / 2, 0);
    newWidth = v_width;
    newHeight = v_height;
    drawImageOnCanvas();
  };
  e_img.src = URL.createObjectURL(e_file.files[0]);
}// JavaScript Document